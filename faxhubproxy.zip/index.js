(async() => {
  await import('./index.mjs');
})();
